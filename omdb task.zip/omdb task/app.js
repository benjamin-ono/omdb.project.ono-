let apikey = "25d513cc";
let url = `http://www.omdbapi.com/?apikey=${apikey}&`;
fetch(url)
.then(function(response){
return response.json();
})
.then(function(data){
console.log(data);
})


